﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH09_Felicia_Tiffany
{
    public partial class Form1 : Form
    {
        DataTable dtuniqme;
        int index = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtuniqme = new DataTable();
            dtuniqme.Columns.Add("Item Name");
            dtuniqme.Columns.Add("Quantity");
            dtuniqme.Columns.Add("Price");
            dtuniqme.Columns.Add("Total");
            dgv_uniqme.DataSource = dtuniqme;
            tb_subtotal.Enabled = false;
            tb_total.Enabled = false;
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_longpants.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = false;
            p_tshirt.Visible = true;
        }

        private void bt_ts1_Click(object sender, EventArgs e)
        {
            Add("White T-Shirt", 120000);
        }

        private void bt_ts2_Click(object sender, EventArgs e)
        {
            Add("Stripe T-Shirt", 150000);
        }

        private void bt_ts3_Click(object sender, EventArgs e)
        {
            Add("Rainbow T-Shirt", 170000);
        }

        private void bt_s1_Click(object sender, EventArgs e)
        {
            Add("White Shirt", 120000);
        }

        private void bt_s2_Click(object sender, EventArgs e)
        {
            Add("Green Shirt", 150000);
        }

        private void bt_s3_Click(object sender, EventArgs e)
        {
            Add("Black Shirt", 170000);
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_pants.Visible = false;
            p_longpants.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = false;
            p_shirt.Visible = true;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_longpants.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = false;
            p_pants.Visible = true;
        }

        private void bt_p1_Click(object sender, EventArgs e)
        {
            Add("Black Pants", 120000);
        }

        private void bt_p2_Click(object sender, EventArgs e)
        {
            Add("Pink Pants", 150000);
        }

        private void bt_p3_Click(object sender, EventArgs e)
        {
            Add("Blue Pants", 170000);
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = false;
            p_longpants.Visible = true;
        }

        private void bt_lp1_Click(object sender, EventArgs e)
        {
            Add("Black Long Pants", 120000);
        }

        private void bt_lp2_Click(object sender, EventArgs e)
        {
            Add("Brown Long Pants", 150000);
        }

        private void bt_lp3_Click(object sender, EventArgs e)
        {
            Add("Jeans Long Pants", 170000);
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_longpants.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = false;
            p_shoes.Visible = true;
        }

        private void bt_sh1_Click(object sender, EventArgs e)
        {
            Add("Adidas Shoes", 120000);
        }

        private void bt_sh2_Click(object sender, EventArgs e)
        {
            Add("Nike Shoes", 150000);
        }

        private void bt_sh3_Click(object sender, EventArgs e)
        {
            Add("New Balance Shoes", 170000);
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_longpants.Visible = false;
            p_shoes.Visible = false;
            p_others.Visible = false;
            p_jewel.Visible = true;
        }

        private void bt_j1_Click(object sender, EventArgs e)
        {
            Add("Heart Necklace", 120000);
        }

        private void bt_j2_Click(object sender, EventArgs e)
        {
            Add("Ring", 150000);
        }

        private void bt_j3_Click(object sender, EventArgs e)
        {
            Add("Star Necklace", 170000);
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            p_tshirt.Visible = false;
            p_shirt.Visible = false;
            p_pants.Visible = false;
            p_longpants.Visible = false;
            p_shoes.Visible = false;
            p_jewel.Visible = false;
            p_others.Visible = true;
        }

        private void bt_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.jpg, *.png, *.bmp)|*.jpg; *.png; *.bmp|All files(.)|*.*";
            ofd.Multiselect = true;

            if(ofd.ShowDialog() == DialogResult.OK)
            {
                pb_add.Image = Image.FromFile(ofd.FileName);
                tb_name.Enabled = true;
                tb_price.Enabled = true;
                bt_addothers.Enabled = true;
            }
        }

        private void bt_addothers_Click(object sender, EventArgs e)
        {
            Add(tb_name.Text, Convert.ToInt32(tb_price.Text));
        }

        private void tb_price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void dgv_uniqme_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            if(index >= 0)
            {
                dtuniqme.Rows.RemoveAt(index);
                dgv_uniqme.DataSource = dtuniqme;
            }
            int total = 0;
            for (int i = 0; i < dtuniqme.Rows.Count; i++)
            {
                total += Convert.ToInt32(dtuniqme.Rows[i][3]);
            }
            tb_subtotal.Text = total.ToString();
            tb_total.Text = Convert.ToString(total + total * 0.1);
        }
        private void Add(string x, int y)
        {
            bool yn = false;
            int z = 0;
            for(int i = 0; i <  dtuniqme.Rows.Count; i++)
            {
                if (dtuniqme.Rows[i][0].ToString().ToLower() == x.ToLower())
                {
                    yn = true;
                    z = i;
                    break;
                }
            }
            if (yn == true)
            {
                dtuniqme.Rows[z][1] = Convert.ToInt32(dtuniqme.Rows[z][1]) + 1;
                dtuniqme.Rows[z][3] = Convert.ToInt32(dtuniqme.Rows[z][1]) * Convert.ToInt32(dtuniqme.Rows[z][2]);
            }
            if (yn  == false)
            {
                dtuniqme.Rows.Add(x, 1, y, y);
            }
            dgv_uniqme.DataSource = dtuniqme;

            int total = 0;
            for (int i = 0; i < dtuniqme.Rows.Count; i++)
            {
                total += Convert.ToInt32(dtuniqme.Rows[i][3]);
            }
            tb_subtotal.Text = total.ToString();
            tb_total.Text = Convert.ToString(total + total * 0.1);
        }
    }
}
