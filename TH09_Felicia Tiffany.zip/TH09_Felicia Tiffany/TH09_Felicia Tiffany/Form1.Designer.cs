﻿namespace TH09_Felicia_Tiffany
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dgv_uniqme = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.p_tshirt = new System.Windows.Forms.Panel();
            this.bt_ts3 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.bt_ts2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bt_ts1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.p_shirt = new System.Windows.Forms.Panel();
            this.bt_s3 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.bt_s2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.bt_s1 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.p_pants = new System.Windows.Forms.Panel();
            this.bt_p3 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.bt_p2 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.bt_p1 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.p_longpants = new System.Windows.Forms.Panel();
            this.bt_lp3 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.bt_lp2 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.bt_lp1 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.p_shoes = new System.Windows.Forms.Panel();
            this.bt_sh3 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.bt_sh2 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.bt_sh1 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.p_jewel = new System.Windows.Forms.Panel();
            this.bt_j3 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.bt_j2 = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.bt_j1 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.p_others = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.bt_upload = new System.Windows.Forms.Button();
            this.pb_add = new System.Windows.Forms.PictureBox();
            this.label40 = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.tb_price = new System.Windows.Forms.TextBox();
            this.bt_addothers = new System.Windows.Forms.Button();
            this.bt_delete = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_uniqme)).BeginInit();
            this.p_tshirt.SuspendLayout();
            this.p_shirt.SuspendLayout();
            this.p_pants.SuspendLayout();
            this.p_longpants.SuspendLayout();
            this.p_shoes.SuspendLayout();
            this.p_jewel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.p_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_add)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(786, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // dgv_uniqme
            // 
            this.dgv_uniqme.AllowUserToResizeColumns = false;
            this.dgv_uniqme.AllowUserToResizeRows = false;
            this.dgv_uniqme.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_uniqme.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_uniqme.Location = new System.Drawing.Point(380, 36);
            this.dgv_uniqme.MultiSelect = false;
            this.dgv_uniqme.Name = "dgv_uniqme";
            this.dgv_uniqme.RowHeadersVisible = false;
            this.dgv_uniqme.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_uniqme.Size = new System.Drawing.Size(394, 210);
            this.dgv_uniqme.TabIndex = 2;
            this.dgv_uniqme.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_uniqme_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(377, 263);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "SUB-TOTAL :";
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(472, 260);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(100, 20);
            this.tb_subtotal.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(409, 292);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "TOTAL :";
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(472, 289);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(100, 20);
            this.tb_total.TabIndex = 6;
            // 
            // p_tshirt
            // 
            this.p_tshirt.Controls.Add(this.bt_ts3);
            this.p_tshirt.Controls.Add(this.label7);
            this.p_tshirt.Controls.Add(this.label8);
            this.p_tshirt.Controls.Add(this.bt_ts2);
            this.p_tshirt.Controls.Add(this.label6);
            this.p_tshirt.Controls.Add(this.label5);
            this.p_tshirt.Controls.Add(this.bt_ts1);
            this.p_tshirt.Controls.Add(this.label4);
            this.p_tshirt.Controls.Add(this.label3);
            this.p_tshirt.Controls.Add(this.pictureBox3);
            this.p_tshirt.Controls.Add(this.pictureBox2);
            this.p_tshirt.Controls.Add(this.pictureBox1);
            this.p_tshirt.Location = new System.Drawing.Point(12, 36);
            this.p_tshirt.Name = "p_tshirt";
            this.p_tshirt.Size = new System.Drawing.Size(359, 227);
            this.p_tshirt.TabIndex = 7;
            this.p_tshirt.Visible = false;
            // 
            // bt_ts3
            // 
            this.bt_ts3.Location = new System.Drawing.Point(260, 175);
            this.bt_ts3.Name = "bt_ts3";
            this.bt_ts3.Size = new System.Drawing.Size(78, 23);
            this.bt_ts3.TabIndex = 11;
            this.bt_ts3.Text = "Add to Cart";
            this.bt_ts3.UseVisualStyleBackColor = true;
            this.bt_ts3.Click += new System.EventHandler(this.bt_ts3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(268, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Rp 170.000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(257, 143);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Rainbow T-Shirt";
            // 
            // bt_ts2
            // 
            this.bt_ts2.Location = new System.Drawing.Point(143, 175);
            this.bt_ts2.Name = "bt_ts2";
            this.bt_ts2.Size = new System.Drawing.Size(78, 23);
            this.bt_ts2.TabIndex = 8;
            this.bt_ts2.Text = "Add to Cart";
            this.bt_ts2.UseVisualStyleBackColor = true;
            this.bt_ts2.Click += new System.EventHandler(this.bt_ts2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(150, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Rp 150.000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(150, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Stripe T-Shirt";
            // 
            // bt_ts1
            // 
            this.bt_ts1.Location = new System.Drawing.Point(25, 175);
            this.bt_ts1.Name = "bt_ts1";
            this.bt_ts1.Size = new System.Drawing.Size(82, 23);
            this.bt_ts1.TabIndex = 5;
            this.bt_ts1.Text = "Add to Cart";
            this.bt_ts1.UseVisualStyleBackColor = true;
            this.bt_ts1.Click += new System.EventHandler(this.bt_ts1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Rp 120.000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "White T-Shirt";
            // 
            // p_shirt
            // 
            this.p_shirt.Controls.Add(this.bt_s3);
            this.p_shirt.Controls.Add(this.label9);
            this.p_shirt.Controls.Add(this.label10);
            this.p_shirt.Controls.Add(this.bt_s2);
            this.p_shirt.Controls.Add(this.label11);
            this.p_shirt.Controls.Add(this.label12);
            this.p_shirt.Controls.Add(this.bt_s1);
            this.p_shirt.Controls.Add(this.label13);
            this.p_shirt.Controls.Add(this.label14);
            this.p_shirt.Controls.Add(this.pictureBox4);
            this.p_shirt.Controls.Add(this.pictureBox5);
            this.p_shirt.Controls.Add(this.pictureBox6);
            this.p_shirt.Location = new System.Drawing.Point(12, 36);
            this.p_shirt.Name = "p_shirt";
            this.p_shirt.Size = new System.Drawing.Size(359, 227);
            this.p_shirt.TabIndex = 12;
            this.p_shirt.Visible = false;
            // 
            // bt_s3
            // 
            this.bt_s3.Location = new System.Drawing.Point(260, 175);
            this.bt_s3.Name = "bt_s3";
            this.bt_s3.Size = new System.Drawing.Size(78, 23);
            this.bt_s3.TabIndex = 11;
            this.bt_s3.Text = "Add to Cart";
            this.bt_s3.UseVisualStyleBackColor = true;
            this.bt_s3.Click += new System.EventHandler(this.bt_s3_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(268, 159);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Rp 170.000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(272, 143);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Black Shirt";
            // 
            // bt_s2
            // 
            this.bt_s2.Location = new System.Drawing.Point(143, 175);
            this.bt_s2.Name = "bt_s2";
            this.bt_s2.Size = new System.Drawing.Size(78, 23);
            this.bt_s2.TabIndex = 8;
            this.bt_s2.Text = "Add to Cart";
            this.bt_s2.UseVisualStyleBackColor = true;
            this.bt_s2.Click += new System.EventHandler(this.bt_s2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(150, 159);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Rp 150.000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(150, 143);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Green Shirt";
            // 
            // bt_s1
            // 
            this.bt_s1.Location = new System.Drawing.Point(25, 175);
            this.bt_s1.Name = "bt_s1";
            this.bt_s1.Size = new System.Drawing.Size(82, 23);
            this.bt_s1.TabIndex = 5;
            this.bt_s1.Text = "Add to Cart";
            this.bt_s1.UseVisualStyleBackColor = true;
            this.bt_s1.Click += new System.EventHandler(this.bt_s1_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 159);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Rp 120.000";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(34, 143);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "White Shirt";
            // 
            // p_pants
            // 
            this.p_pants.Controls.Add(this.bt_p3);
            this.p_pants.Controls.Add(this.label15);
            this.p_pants.Controls.Add(this.label16);
            this.p_pants.Controls.Add(this.bt_p2);
            this.p_pants.Controls.Add(this.label17);
            this.p_pants.Controls.Add(this.label18);
            this.p_pants.Controls.Add(this.bt_p1);
            this.p_pants.Controls.Add(this.label19);
            this.p_pants.Controls.Add(this.label20);
            this.p_pants.Controls.Add(this.pictureBox7);
            this.p_pants.Controls.Add(this.pictureBox8);
            this.p_pants.Controls.Add(this.pictureBox9);
            this.p_pants.Location = new System.Drawing.Point(12, 36);
            this.p_pants.Name = "p_pants";
            this.p_pants.Size = new System.Drawing.Size(359, 227);
            this.p_pants.TabIndex = 13;
            this.p_pants.Visible = false;
            // 
            // bt_p3
            // 
            this.bt_p3.Location = new System.Drawing.Point(260, 175);
            this.bt_p3.Name = "bt_p3";
            this.bt_p3.Size = new System.Drawing.Size(78, 23);
            this.bt_p3.TabIndex = 11;
            this.bt_p3.Text = "Add to Cart";
            this.bt_p3.UseVisualStyleBackColor = true;
            this.bt_p3.Click += new System.EventHandler(this.bt_p3_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(268, 159);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 13);
            this.label15.TabIndex = 10;
            this.label15.Text = "Rp 170.000";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(272, 143);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 13);
            this.label16.TabIndex = 9;
            this.label16.Text = "Blue Pants";
            // 
            // bt_p2
            // 
            this.bt_p2.Location = new System.Drawing.Point(143, 175);
            this.bt_p2.Name = "bt_p2";
            this.bt_p2.Size = new System.Drawing.Size(78, 23);
            this.bt_p2.TabIndex = 8;
            this.bt_p2.Text = "Add to Cart";
            this.bt_p2.UseVisualStyleBackColor = true;
            this.bt_p2.Click += new System.EventHandler(this.bt_p2_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(150, 159);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 13);
            this.label17.TabIndex = 7;
            this.label17.Text = "Rp 150.000";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(150, 143);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "Pink Pants";
            // 
            // bt_p1
            // 
            this.bt_p1.Location = new System.Drawing.Point(25, 175);
            this.bt_p1.Name = "bt_p1";
            this.bt_p1.Size = new System.Drawing.Size(82, 23);
            this.bt_p1.TabIndex = 5;
            this.bt_p1.Text = "Add to Cart";
            this.bt_p1.UseVisualStyleBackColor = true;
            this.bt_p1.Click += new System.EventHandler(this.bt_p1_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(32, 159);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(63, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "Rp 120.000";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(34, 143);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(64, 13);
            this.label20.TabIndex = 3;
            this.label20.Text = "Black Pants";
            // 
            // p_longpants
            // 
            this.p_longpants.Controls.Add(this.bt_lp3);
            this.p_longpants.Controls.Add(this.label21);
            this.p_longpants.Controls.Add(this.label22);
            this.p_longpants.Controls.Add(this.bt_lp2);
            this.p_longpants.Controls.Add(this.label23);
            this.p_longpants.Controls.Add(this.label24);
            this.p_longpants.Controls.Add(this.bt_lp1);
            this.p_longpants.Controls.Add(this.label25);
            this.p_longpants.Controls.Add(this.label26);
            this.p_longpants.Controls.Add(this.pictureBox10);
            this.p_longpants.Controls.Add(this.pictureBox11);
            this.p_longpants.Controls.Add(this.pictureBox12);
            this.p_longpants.Location = new System.Drawing.Point(12, 36);
            this.p_longpants.Name = "p_longpants";
            this.p_longpants.Size = new System.Drawing.Size(359, 227);
            this.p_longpants.TabIndex = 14;
            this.p_longpants.Visible = false;
            // 
            // bt_lp3
            // 
            this.bt_lp3.Location = new System.Drawing.Point(260, 175);
            this.bt_lp3.Name = "bt_lp3";
            this.bt_lp3.Size = new System.Drawing.Size(78, 23);
            this.bt_lp3.TabIndex = 11;
            this.bt_lp3.Text = "Add to Cart";
            this.bt_lp3.UseVisualStyleBackColor = true;
            this.bt_lp3.Click += new System.EventHandler(this.bt_lp3_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(268, 159);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 13);
            this.label21.TabIndex = 10;
            this.label21.Text = "Rp 170.000";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(252, 143);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(92, 13);
            this.label22.TabIndex = 9;
            this.label22.Text = "Jeans Long Pants";
            // 
            // bt_lp2
            // 
            this.bt_lp2.Location = new System.Drawing.Point(143, 175);
            this.bt_lp2.Name = "bt_lp2";
            this.bt_lp2.Size = new System.Drawing.Size(78, 23);
            this.bt_lp2.TabIndex = 8;
            this.bt_lp2.Text = "Add to Cart";
            this.bt_lp2.UseVisualStyleBackColor = true;
            this.bt_lp2.Click += new System.EventHandler(this.bt_lp2_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(150, 159);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(63, 13);
            this.label23.TabIndex = 7;
            this.label23.Text = "Rp 150.000";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(135, 143);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(94, 13);
            this.label24.TabIndex = 6;
            this.label24.Text = "Brown Long Pants";
            // 
            // bt_lp1
            // 
            this.bt_lp1.Location = new System.Drawing.Point(25, 175);
            this.bt_lp1.Name = "bt_lp1";
            this.bt_lp1.Size = new System.Drawing.Size(82, 23);
            this.bt_lp1.TabIndex = 5;
            this.bt_lp1.Text = "Add to Cart";
            this.bt_lp1.UseVisualStyleBackColor = true;
            this.bt_lp1.Click += new System.EventHandler(this.bt_lp1_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(32, 159);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(63, 13);
            this.label25.TabIndex = 4;
            this.label25.Text = "Rp 120.000";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(22, 143);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(91, 13);
            this.label26.TabIndex = 3;
            this.label26.Text = "Black Long Pants";
            // 
            // p_shoes
            // 
            this.p_shoes.Controls.Add(this.bt_sh3);
            this.p_shoes.Controls.Add(this.label27);
            this.p_shoes.Controls.Add(this.label28);
            this.p_shoes.Controls.Add(this.bt_sh2);
            this.p_shoes.Controls.Add(this.label29);
            this.p_shoes.Controls.Add(this.label30);
            this.p_shoes.Controls.Add(this.bt_sh1);
            this.p_shoes.Controls.Add(this.label31);
            this.p_shoes.Controls.Add(this.label32);
            this.p_shoes.Controls.Add(this.pictureBox13);
            this.p_shoes.Controls.Add(this.pictureBox14);
            this.p_shoes.Controls.Add(this.pictureBox15);
            this.p_shoes.Location = new System.Drawing.Point(12, 36);
            this.p_shoes.Name = "p_shoes";
            this.p_shoes.Size = new System.Drawing.Size(359, 227);
            this.p_shoes.TabIndex = 15;
            this.p_shoes.Visible = false;
            // 
            // bt_sh3
            // 
            this.bt_sh3.Location = new System.Drawing.Point(260, 175);
            this.bt_sh3.Name = "bt_sh3";
            this.bt_sh3.Size = new System.Drawing.Size(78, 23);
            this.bt_sh3.TabIndex = 11;
            this.bt_sh3.Text = "Add to Cart";
            this.bt_sh3.UseVisualStyleBackColor = true;
            this.bt_sh3.Click += new System.EventHandler(this.bt_sh3_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(268, 159);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(63, 13);
            this.label27.TabIndex = 10;
            this.label27.Text = "Rp 170.000";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(245, 143);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(104, 13);
            this.label28.TabIndex = 9;
            this.label28.Text = "New Balance Shoes";
            // 
            // bt_sh2
            // 
            this.bt_sh2.Location = new System.Drawing.Point(143, 175);
            this.bt_sh2.Name = "bt_sh2";
            this.bt_sh2.Size = new System.Drawing.Size(78, 23);
            this.bt_sh2.TabIndex = 8;
            this.bt_sh2.Text = "Add to Cart";
            this.bt_sh2.UseVisualStyleBackColor = true;
            this.bt_sh2.Click += new System.EventHandler(this.bt_sh2_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(150, 159);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(63, 13);
            this.label29.TabIndex = 7;
            this.label29.Text = "Rp 150.000";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(151, 143);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(62, 13);
            this.label30.TabIndex = 6;
            this.label30.Text = "Nike Shoes";
            // 
            // bt_sh1
            // 
            this.bt_sh1.Location = new System.Drawing.Point(25, 175);
            this.bt_sh1.Name = "bt_sh1";
            this.bt_sh1.Size = new System.Drawing.Size(82, 23);
            this.bt_sh1.TabIndex = 5;
            this.bt_sh1.Text = "Add to Cart";
            this.bt_sh1.UseVisualStyleBackColor = true;
            this.bt_sh1.Click += new System.EventHandler(this.bt_sh1_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(32, 159);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(63, 13);
            this.label31.TabIndex = 4;
            this.label31.Text = "Rp 120.000";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(29, 143);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(72, 13);
            this.label32.TabIndex = 3;
            this.label32.Text = "Adidas Shoes";
            // 
            // p_jewel
            // 
            this.p_jewel.Controls.Add(this.bt_j3);
            this.p_jewel.Controls.Add(this.label33);
            this.p_jewel.Controls.Add(this.label34);
            this.p_jewel.Controls.Add(this.bt_j2);
            this.p_jewel.Controls.Add(this.label35);
            this.p_jewel.Controls.Add(this.label36);
            this.p_jewel.Controls.Add(this.bt_j1);
            this.p_jewel.Controls.Add(this.label37);
            this.p_jewel.Controls.Add(this.label38);
            this.p_jewel.Controls.Add(this.pictureBox16);
            this.p_jewel.Controls.Add(this.pictureBox17);
            this.p_jewel.Controls.Add(this.pictureBox18);
            this.p_jewel.Location = new System.Drawing.Point(12, 36);
            this.p_jewel.Name = "p_jewel";
            this.p_jewel.Size = new System.Drawing.Size(359, 227);
            this.p_jewel.TabIndex = 16;
            this.p_jewel.Visible = false;
            // 
            // bt_j3
            // 
            this.bt_j3.Location = new System.Drawing.Point(260, 175);
            this.bt_j3.Name = "bt_j3";
            this.bt_j3.Size = new System.Drawing.Size(78, 23);
            this.bt_j3.TabIndex = 11;
            this.bt_j3.Text = "Add to Cart";
            this.bt_j3.UseVisualStyleBackColor = true;
            this.bt_j3.Click += new System.EventHandler(this.bt_j3_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(268, 159);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(63, 13);
            this.label33.TabIndex = 10;
            this.label33.Text = "Rp 170.000";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(261, 143);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(75, 13);
            this.label34.TabIndex = 9;
            this.label34.Text = "Star Necklace";
            // 
            // bt_j2
            // 
            this.bt_j2.Location = new System.Drawing.Point(143, 175);
            this.bt_j2.Name = "bt_j2";
            this.bt_j2.Size = new System.Drawing.Size(78, 23);
            this.bt_j2.TabIndex = 8;
            this.bt_j2.Text = "Add to Cart";
            this.bt_j2.UseVisualStyleBackColor = true;
            this.bt_j2.Click += new System.EventHandler(this.bt_j2_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(150, 159);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(63, 13);
            this.label35.TabIndex = 7;
            this.label35.Text = "Rp 150.000";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(166, 143);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 13);
            this.label36.TabIndex = 6;
            this.label36.Text = "Ring";
            // 
            // bt_j1
            // 
            this.bt_j1.Location = new System.Drawing.Point(25, 175);
            this.bt_j1.Name = "bt_j1";
            this.bt_j1.Size = new System.Drawing.Size(82, 23);
            this.bt_j1.TabIndex = 5;
            this.bt_j1.Text = "Add to Cart";
            this.bt_j1.UseVisualStyleBackColor = true;
            this.bt_j1.Click += new System.EventHandler(this.bt_j1_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(32, 159);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(63, 13);
            this.label37.TabIndex = 4;
            this.label37.Text = "Rp 120.000";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(26, 143);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(82, 13);
            this.label38.TabIndex = 3;
            this.label38.Text = "Heart Necklace";
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::TH09_Felicia_Tiffany.Properties.Resources.star_necklace;
            this.pictureBox16.Location = new System.Drawing.Point(247, 13);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(100, 126);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 2;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::TH09_Felicia_Tiffany.Properties.Resources.ring;
            this.pictureBox17.Location = new System.Drawing.Point(131, 13);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(100, 126);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 1;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::TH09_Felicia_Tiffany.Properties.Resources.heart_necklace;
            this.pictureBox18.InitialImage = global::TH09_Felicia_Tiffany.Properties.Resources.white_tshirt;
            this.pictureBox18.Location = new System.Drawing.Point(16, 13);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(100, 126);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 0;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::TH09_Felicia_Tiffany.Properties.Resources.new_balance;
            this.pictureBox13.Location = new System.Drawing.Point(247, 13);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(100, 126);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 2;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::TH09_Felicia_Tiffany.Properties.Resources.nike;
            this.pictureBox14.Location = new System.Drawing.Point(131, 13);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(100, 126);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 1;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::TH09_Felicia_Tiffany.Properties.Resources.adidas;
            this.pictureBox15.InitialImage = global::TH09_Felicia_Tiffany.Properties.Resources.white_tshirt;
            this.pictureBox15.Location = new System.Drawing.Point(16, 13);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(100, 126);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::TH09_Felicia_Tiffany.Properties.Resources.jeans_lpants;
            this.pictureBox10.Location = new System.Drawing.Point(247, 13);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(100, 126);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 2;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::TH09_Felicia_Tiffany.Properties.Resources.brown_lpants;
            this.pictureBox11.Location = new System.Drawing.Point(131, 13);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(100, 126);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 1;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::TH09_Felicia_Tiffany.Properties.Resources.black_lpants;
            this.pictureBox12.InitialImage = global::TH09_Felicia_Tiffany.Properties.Resources.white_tshirt;
            this.pictureBox12.Location = new System.Drawing.Point(16, 13);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(100, 126);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 0;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::TH09_Felicia_Tiffany.Properties.Resources.blue_pants;
            this.pictureBox7.Location = new System.Drawing.Point(247, 13);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(100, 126);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::TH09_Felicia_Tiffany.Properties.Resources.pink_pants;
            this.pictureBox8.Location = new System.Drawing.Point(131, 13);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(100, 126);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::TH09_Felicia_Tiffany.Properties.Resources.black_pants;
            this.pictureBox9.InitialImage = global::TH09_Felicia_Tiffany.Properties.Resources.white_tshirt;
            this.pictureBox9.Location = new System.Drawing.Point(16, 13);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(100, 126);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::TH09_Felicia_Tiffany.Properties.Resources.black_shirt;
            this.pictureBox4.Location = new System.Drawing.Point(247, 13);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 126);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::TH09_Felicia_Tiffany.Properties.Resources.green_shirt;
            this.pictureBox5.Location = new System.Drawing.Point(131, 13);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(100, 126);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::TH09_Felicia_Tiffany.Properties.Resources.white_shirt;
            this.pictureBox6.InitialImage = global::TH09_Felicia_Tiffany.Properties.Resources.white_tshirt;
            this.pictureBox6.Location = new System.Drawing.Point(16, 13);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(100, 126);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::TH09_Felicia_Tiffany.Properties.Resources.rainbow_tshirt;
            this.pictureBox3.Location = new System.Drawing.Point(247, 13);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 126);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::TH09_Felicia_Tiffany.Properties.Resources.stripe_tshirt;
            this.pictureBox2.Location = new System.Drawing.Point(131, 13);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 126);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TH09_Felicia_Tiffany.Properties.Resources.white_tshirt;
            this.pictureBox1.InitialImage = global::TH09_Felicia_Tiffany.Properties.Resources.white_tshirt;
            this.pictureBox1.Location = new System.Drawing.Point(16, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 126);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // p_others
            // 
            this.p_others.Controls.Add(this.bt_addothers);
            this.p_others.Controls.Add(this.tb_price);
            this.p_others.Controls.Add(this.label41);
            this.p_others.Controls.Add(this.tb_name);
            this.p_others.Controls.Add(this.label40);
            this.p_others.Controls.Add(this.pb_add);
            this.p_others.Controls.Add(this.bt_upload);
            this.p_others.Controls.Add(this.label39);
            this.p_others.Location = new System.Drawing.Point(12, 36);
            this.p_others.Name = "p_others";
            this.p_others.Size = new System.Drawing.Size(359, 227);
            this.p_others.TabIndex = 17;
            this.p_others.Visible = false;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(13, 29);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 16);
            this.label39.TabIndex = 17;
            this.label39.Text = "Upload Image :";
            // 
            // bt_upload
            // 
            this.bt_upload.Location = new System.Drawing.Point(122, 26);
            this.bt_upload.Name = "bt_upload";
            this.bt_upload.Size = new System.Drawing.Size(75, 23);
            this.bt_upload.TabIndex = 18;
            this.bt_upload.Text = "Upload";
            this.bt_upload.UseVisualStyleBackColor = true;
            this.bt_upload.Click += new System.EventHandler(this.bt_upload_Click);
            // 
            // pb_add
            // 
            this.pb_add.Location = new System.Drawing.Point(16, 60);
            this.pb_add.Name = "pb_add";
            this.pb_add.Size = new System.Drawing.Size(100, 127);
            this.pb_add.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_add.TabIndex = 19;
            this.pb_add.TabStop = false;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(128, 69);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(64, 13);
            this.label40.TabIndex = 20;
            this.label40.Text = "Item Name :";
            // 
            // tb_name
            // 
            this.tb_name.Enabled = false;
            this.tb_name.Location = new System.Drawing.Point(130, 87);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(100, 20);
            this.tb_name.TabIndex = 17;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(128, 126);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(60, 13);
            this.label41.TabIndex = 21;
            this.label41.Text = "Item Price :";
            // 
            // tb_price
            // 
            this.tb_price.Enabled = false;
            this.tb_price.Location = new System.Drawing.Point(131, 145);
            this.tb_price.Name = "tb_price";
            this.tb_price.Size = new System.Drawing.Size(100, 20);
            this.tb_price.TabIndex = 22;
            this.tb_price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_price_KeyPress);
            // 
            // bt_addothers
            // 
            this.bt_addothers.Enabled = false;
            this.bt_addothers.Location = new System.Drawing.Point(130, 175);
            this.bt_addothers.Name = "bt_addothers";
            this.bt_addothers.Size = new System.Drawing.Size(75, 23);
            this.bt_addothers.TabIndex = 23;
            this.bt_addothers.Text = "Add to Cart";
            this.bt_addothers.UseVisualStyleBackColor = true;
            this.bt_addothers.Click += new System.EventHandler(this.bt_addothers_Click);
            // 
            // bt_delete
            // 
            this.bt_delete.Location = new System.Drawing.Point(699, 252);
            this.bt_delete.Name = "bt_delete";
            this.bt_delete.Size = new System.Drawing.Size(75, 23);
            this.bt_delete.TabIndex = 24;
            this.bt_delete.Text = "Delete";
            this.bt_delete.UseVisualStyleBackColor = true;
            this.bt_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 345);
            this.Controls.Add(this.bt_delete);
            this.Controls.Add(this.p_others);
            this.Controls.Add(this.p_jewel);
            this.Controls.Add(this.p_shoes);
            this.Controls.Add(this.p_longpants);
            this.Controls.Add(this.p_pants);
            this.Controls.Add(this.p_shirt);
            this.Controls.Add(this.p_tshirt);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv_uniqme);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Uniqme";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_uniqme)).EndInit();
            this.p_tshirt.ResumeLayout(false);
            this.p_tshirt.PerformLayout();
            this.p_shirt.ResumeLayout(false);
            this.p_shirt.PerformLayout();
            this.p_pants.ResumeLayout(false);
            this.p_pants.PerformLayout();
            this.p_longpants.ResumeLayout(false);
            this.p_longpants.PerformLayout();
            this.p_shoes.ResumeLayout(false);
            this.p_shoes.PerformLayout();
            this.p_jewel.ResumeLayout(false);
            this.p_jewel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.p_others.ResumeLayout(false);
            this.p_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_add)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.DataGridView dgv_uniqme;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Panel p_tshirt;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bt_ts1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_ts3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button bt_ts2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel p_shirt;
        private System.Windows.Forms.Button bt_s3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button bt_s2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button bt_s1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel p_pants;
        private System.Windows.Forms.Button bt_p3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button bt_p2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button bt_p1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel p_longpants;
        private System.Windows.Forms.Button bt_lp3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button bt_lp2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button bt_lp1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Panel p_shoes;
        private System.Windows.Forms.Button bt_sh3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button bt_sh2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button bt_sh1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Panel p_jewel;
        private System.Windows.Forms.Button bt_j3;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button bt_j2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button bt_j1;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Panel p_others;
        private System.Windows.Forms.PictureBox pb_add;
        private System.Windows.Forms.Button bt_upload;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button bt_addothers;
        private System.Windows.Forms.TextBox tb_price;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button bt_delete;
    }
}

